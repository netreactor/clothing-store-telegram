import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { apiClient } from '@/api/client';
import type { HeroContent, HeroSlide } from '@/types';

interface DatabaseContextType {
  categories: any[];
  subcategories: any[];
  products: any[];
  posts: any[];
  adminUsers: any[];
  heroContent: HeroContent | null;
  heroSlides: HeroSlide[];
  
  // Categories
  addCategory: (name: string, icon: string) => Promise<void>;
  deleteCategory: (id: number) => Promise<void>;
  
  // Subcategories
  getSubcategoriesByCategory: (categoryId: number) => any[];
  addSubcategory: (name: string, categoryId: number) => Promise<void>;
  deleteSubcategory: (id: number) => Promise<void>;
  
  // Products
  getProductsBySubcategory: (subcategoryId: number) => any[];
  searchProducts: (query: string) => Promise<void>;
  addProduct: (product: any) => Promise<void>;
  updateProduct: (id: number, product: any) => Promise<void>;
  deleteProduct: (id: number) => Promise<void>;
  
  // Posts
  addPost: (post: any) => Promise<void>;
  updatePost: (id: number, post: any) => Promise<void>;
  deletePost: (id: number) => Promise<void>;

  // Hero
  updateHeroContent: (payload: { title: string; description: string }) => Promise<void>;
  addHeroSlide: (slide: { image_url: string; caption?: string | null; sort_order?: number }) => Promise<void>;
  updateHeroSlide: (id: number, slide: { image_url: string; caption?: string | null; sort_order: number }) => Promise<void>;
  deleteHeroSlide: (id: number) => Promise<void>;
  
  // Admin Users
  getAdminUserByUsername: (username: string) => any | null;
  addAdminUser: (user: any) => Promise<void>;
  updateAdminUser: (id: number, user: any) => Promise<void>;
  deleteAdminUser: (id: number) => Promise<void>;
  
  isLoading: boolean;
  refreshData: () => Promise<void>;
}

const DatabaseContext = createContext<DatabaseContextType | undefined>(undefined);

export function DatabaseProvider({ children }: { children: ReactNode }) {
  const [categories, setCategories] = useState<any[]>([]);
  const [subcategories, setSubcategories] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [posts, setPosts] = useState<any[]>([]);
  const [adminUsers, setAdminUsers] = useState<any[]>([]);
  const [heroContent, setHeroContent] = useState<HeroContent | null>(null);
  const [heroSlides, setHeroSlides] = useState<HeroSlide[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [categoriesData, subcategoriesData, productsData, postsData, adminUsersData, heroContentData, heroSlidesData] = await Promise.all([
        apiClient.getCategories(),
        apiClient.getSubcategories(),
        apiClient.getProducts(),
        apiClient.getPosts(),
        apiClient.getAdminUsers(),
        apiClient.getHeroContent(),
        apiClient.getHeroSlides(),
      ]);

      setCategories(categoriesData);
      setSubcategories(subcategoriesData);
      setProducts(productsData);
      setPosts(postsData);
      setAdminUsers(adminUsersData);
      setHeroContent(heroContentData);
      setHeroSlides(heroSlidesData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Categories
  const addCategory = async (name: string, icon: string) => {
    await apiClient.addCategory(name, icon);
    await loadData();
  };

  const deleteCategory = async (id: number) => {
    await apiClient.deleteCategory(id);
    await loadData();
  };

  // Subcategories
  const getSubcategoriesByCategory = (categoryId: number) => {
    return subcategories.filter(s => s.category_id === categoryId);
  };

  const addSubcategory = async (name: string, categoryId: number) => {
    await apiClient.addSubcategory(name, categoryId);
    await loadData();
  };

  const deleteSubcategory = async (id: number) => {
    await apiClient.deleteSubcategory(id);
    await loadData();
  };

  // Products
  const getProductsBySubcategory = (subcategoryId: number) => {
    return products.filter(p => p.subcategory_id === subcategoryId);
  };

  const searchProducts = async (query: string) => {
    const results = await apiClient.getProducts(undefined, query);
    setProducts(results);
  };

  const addProduct = async (product: any) => {
    await apiClient.addProduct(product);
    await loadData();
  };

  const updateProduct = async (id: number, product: any) => {
    await apiClient.updateProduct(id, product);
    await loadData();
  };

  const deleteProduct = async (id: number) => {
    await apiClient.deleteProduct(id);
    await loadData();
  };

  // Posts
  const addPost = async (post: any) => {
    await apiClient.addPost(post);
    await loadData();
  };

  const updatePost = async (id: number, post: any) => {
    await apiClient.updatePost(id, post);
    await loadData();
  };

  const deletePost = async (id: number) => {
    await apiClient.deletePost(id);
    await loadData();
  };

  // Hero
  const updateHeroContent = async (payload: { title: string; description: string }) => {
    await apiClient.updateHeroContent(payload);
    await loadData();
  };

  const addHeroSlide = async (slide: { image_url: string; caption?: string | null; sort_order?: number }) => {
    await apiClient.addHeroSlide(slide);
    await loadData();
  };

  const updateHeroSlide = async (id: number, slide: { image_url: string; caption?: string | null; sort_order: number }) => {
    await apiClient.updateHeroSlide(id, slide);
    await loadData();
  };

  const deleteHeroSlide = async (id: number) => {
    await apiClient.deleteHeroSlide(id);
    await loadData();
  };

  // Admin Users
  const getAdminUserByUsername = (username: string) => {
    return adminUsers.find(u => u.username === username) || null;
  };

  const addAdminUser = async (user: any) => {
    await apiClient.addAdminUser(user);
    await loadData();
  };

  const updateAdminUser = async (id: number, user: any) => {
    await apiClient.updateAdminUser(id, user);
    await loadData();
  };

  const deleteAdminUser = async (id: number) => {
    await apiClient.deleteAdminUser(id);
    await loadData();
  };

  const value: DatabaseContextType = {
    categories,
    subcategories,
    products,
    posts,
    adminUsers,
    heroContent,
    heroSlides,
    addCategory,
    deleteCategory,
    getSubcategoriesByCategory,
    addSubcategory,
    deleteSubcategory,
    getProductsBySubcategory,
    searchProducts,
    addProduct,
    updateProduct,
    deleteProduct,
    addPost,
    updatePost,
    deletePost,
    updateHeroContent,
    addHeroSlide,
    updateHeroSlide,
    deleteHeroSlide,
    getAdminUserByUsername,
    addAdminUser,
    updateAdminUser,
    deleteAdminUser,
    isLoading,
    refreshData: loadData,
  };

  return (
    <DatabaseContext.Provider value={value}>
      {children}
    </DatabaseContext.Provider>
  );
}

export function useDatabase() {
  const context = useContext(DatabaseContext);
  if (context === undefined) {
    throw new Error('useDatabase must be used within a DatabaseProvider');
  }
  return context;
}
