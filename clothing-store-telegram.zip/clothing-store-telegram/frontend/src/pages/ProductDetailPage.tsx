import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDatabase } from '@/context/DatabaseContext';
import { Star, ShoppingBag, ArrowLeft, Heart, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ThemeToggle from '@/components/ThemeToggle';
import { useTheme } from '@/context/ThemeContext';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { products, subcategories, categories } = useDatabase();
  const [product, setProduct] = useState<any>(null);
  const { theme } = useTheme();
  const [isImageLoaded, setIsImageLoaded] = useState(false);

  useEffect(() => {
    if (id) {
      const foundProduct = products.find(p => p.id === parseInt(id));
      if (foundProduct) {
        setProduct(foundProduct);
      }
    }
  }, [id, products]);

  if (!product) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500 text-lg">Товар не найден</p>
          <Button 
            onClick={() => navigate('/')} 
            className="mt-4 bg-black text-white hover:bg-gray-800"
          >
            Вернуться на главную
          </Button>
        </div>
      </div>
    );
  }

  const subcategory = subcategories.find(s => s.id === product.subcategory_id);
  const category = subcategory ? categories.find(c => c.id === subcategory.category_id) : null;

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-5 h-5 ${i < rating ? 'fill-black text-black' : 'text-gray-300'}`}
      />
    ));
  };

  return (
    <div className="theme-root min-h-screen bg-white" data-theme={theme}>
      {/* Header */}
      <header className="border-b border-gray-100 sticky top-0 bg-white/95 backdrop-blur-sm z-50">
        <div className="flex items-center justify-between px-4 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => navigate('/')}
              className="hover:bg-gray-100"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-xl font-bold tracking-tight">CLOTHING STORE</h1>
          </div>
          
          <div className="flex items-center gap-4">
            <ThemeToggle />
            <a 
              href="#/admin" 
              className="text-sm text-gray-500 hover:text-black transition-colors"
            >
              Админ панель
            </a>
          </div>
        </div>
      </header>

      {/* Breadcrumb */}
      <div className="px-4 lg:px-8 py-4 border-b border-gray-100">
        <nav className="flex items-center gap-2 text-sm text-gray-500">
          <span 
            className="hover:text-black cursor-pointer transition-colors"
            onClick={() => navigate('/')}
          >
            Главная
          </span>
          <span>/</span>
          {category && (
            <>
              <span 
                className="hover:text-black cursor-pointer transition-colors"
                onClick={() => navigate(`/?category=${category.id}`)}
              >
                {category.name}
              </span>
              <span>/</span>
            </>
          )}
          {subcategory && (
            <>
              <span 
                className="hover:text-black cursor-pointer transition-colors"
                onClick={() => navigate(`/?subcategory=${subcategory.id}`)}
              >
                {subcategory.name}
              </span>
              <span>/</span>
            </>
          )}
          <span className="text-black font-medium">{product.name}</span>
        </nav>
      </div>

      {/* Product Content */}
      <main className="px-4 lg:px-8 py-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16">
            {/* Image Section */}
            <div className="space-y-4">
              <div className="aspect-square bg-gray-50 rounded-2xl overflow-hidden relative group">
                {!isImageLoaded && (
                  <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
                    <div className="w-12 h-12 border-2 border-gray-300 border-t-black rounded-full animate-spin" />
                  </div>
                )}
                <img
                  src={product.image_url || '/placeholder.png'}
                  alt={product.name}
                  className={`w-full h-full object-contain transition-transform duration-500 group-hover:scale-[1.02] p-3 ${
                    isImageLoaded ? 'opacity-100' : 'opacity-0'
                  }`}
                  onLoad={() => setIsImageLoaded(true)}
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgZmlsbD0iI2Y1ZjVmNSIvPjx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0ic2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5vIEltYWdlPC90ZXh0Pjwvc3ZnPg==';
                    setIsImageLoaded(true);
                  }}
                />
                
                {/* Action buttons overlay */}
                <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button 
                    variant="secondary" 
                    size="icon"
                    className="bg-white/90 backdrop-blur-sm hover:bg-white shadow-lg"
                  >
                    <Heart className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="secondary" 
                    size="icon"
                    className="bg-white/90 backdrop-blur-sm hover:bg-white shadow-lg"
                  >
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Info Section */}
            <div className="space-y-6">
              {/* Category Badge */}
              {subcategory && (
                <Badge variant="secondary" className="bg-gray-100 text-gray-700 hover:bg-gray-200">
                  {subcategory.name}
                </Badge>
              )}

              {/* Title */}
              <h1 className="text-3xl lg:text-4xl font-bold text-black leading-tight">
                {product.name}
              </h1>

              {/* Rating */}
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1">
                  {renderStars(product.rating)}
                </div>
                <span className="text-gray-500 text-sm">
                  Рейтинг: {product.rating}/5
                </span>
              </div>

              <Separator className="bg-gray-100" />

              {/* Description */}
              <div className="space-y-3">
                <h2 className="text-lg font-semibold">Описание</h2>
                <p className="text-gray-600 leading-relaxed">
                  {product.description || 'Описание отсутствует'}
                </p>
              </div>

              <Separator className="bg-gray-100" />

              {/* Order Button */}
              <div className="pt-4">
                <Button 
                  size="lg"
                  className="w-full sm:w-auto bg-black text-white hover:bg-gray-800 px-12 py-6 text-lg rounded-xl shadow-lg hover:shadow-xl transition-all"
                  onClick={() => product.order_link && window.open(product.order_link, '_blank')}
                >
                  <ShoppingBag className="w-5 h-5 mr-3" />
                  Заказать
                </Button>
              </div>

              {/* Additional Info */}
              <div className="bg-gray-50 rounded-xl p-6 space-y-4">
                <h3 className="font-semibold text-gray-900">Информация о товаре</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">Артикул:</span>
                    <p className="font-medium text-black">{product.article || '—'}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Категория:</span>
                    <p className="font-medium text-black">{category?.name || '—'}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Подкатегория:</span>
                    <p className="font-medium text-black">{subcategory?.name || '—'}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
