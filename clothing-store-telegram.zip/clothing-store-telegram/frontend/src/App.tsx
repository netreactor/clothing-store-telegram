import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { DatabaseProvider } from '@/context/DatabaseContext';
import { TelegramProvider } from '@/context/TelegramContext';
import { AuthProvider } from '@/context/AuthContext';
import StorePage from '@/pages/StorePage';
import AdminPage from '@/pages/AdminPage';
import ProductDetailPage from '@/pages/ProductDetailPage';
import { ThemeProvider } from '@/context/ThemeContext';
import './App.css';

function App() {
  return (
    <ThemeProvider>
      <TelegramProvider>
        <AuthProvider>
          <DatabaseProvider>
            <Router>
              <Routes>
                <Route path="/" element={<StorePage />} />
                <Route path="/product/:id" element={<ProductDetailPage />} />
                <Route path="/admin" element={<AdminPage />} />
              </Routes>
            </Router>
          </DatabaseProvider>
        </AuthProvider>
      </TelegramProvider>
    </ThemeProvider>
  );
}

export default App;
