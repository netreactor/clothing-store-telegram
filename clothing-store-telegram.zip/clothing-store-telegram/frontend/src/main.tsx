import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Wait for Telegram WebApp SDK to load before mounting React
const initApp = () => {
  const rootElement = document.getElementById('root');
  
  if (!rootElement) {
    throw new Error('Root element not found');
  }

  createRoot(rootElement).render(
    <StrictMode>
      <App />
    </StrictMode>
  );
};

// Check if Telegram WebApp SDK is already loaded
if (window.Telegram?.WebApp) {
  console.log('✅ Telegram WebApp SDK loaded');
  initApp();
} else {
  // If not in Telegram environment, just initialize normally
  console.log('⚠️ Not in Telegram environment');
  initApp();
}
